const express=require('express');
const app=express();
const path=require('path'); //to set the path of views folder



app.set('view engine','ejs'); //view engines ko set krdia hai taki baki templates dekh pao
app.set('views',path.join(__dirname,'views')); //views folder ko set krdia hai jahan se templates milenge    


//root route
app.get('/',(req,res)=>{
    //res.send('<h1>Home Page</h1>');
    res.render('index');
})


app.listen(8080,()=>{
    console.log('connected successfully');
})