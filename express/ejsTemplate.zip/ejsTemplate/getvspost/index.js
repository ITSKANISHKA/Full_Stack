const express=require('express');
const app=express();
const path=require('path');


app.set('view engine','ejs')
app.set('views',path.join(__dirname,'views'))
app.use(express.static(path.join(__dirname,'public') ));

app.get('/',(req,res)=>{
    res.render('index');
})

app.use(express. urlencoded({extended:true})); //for parsing application/x-www-form-urlencoded
app.use(express.json()); //midddleware for json data

//get request ko handle krne ke liyee
app.get('/user',(req,res)=>{
    console.log(req.query);
    let{username,age}=req.query;
    res.send('get request successful')
})

 
//post request ko handle krne ke liye humein body parser ki jarurat padegi
app.post('/user',(req,res)=>{
    console.log(req.body); 
    res.send('post')
})




app.listen(8080,()=>{
    console.log("server is connected")
})