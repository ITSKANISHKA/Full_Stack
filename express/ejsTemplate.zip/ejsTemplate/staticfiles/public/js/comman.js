let btn=document.querySelector('#btn');
btn.addEventListener('click',()=>{
    console.log('button click krdia hai in comman js file');
})