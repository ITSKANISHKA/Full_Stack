const Express=require('express');
cont=app=Express();


app.get('/search',(req,res)=>{
    // res.send('Search Page');
    console.log(req.query);
    console.log(req.query.search);

})





app.listen(8080,()=>{
    console.log('connected successfully');
});
