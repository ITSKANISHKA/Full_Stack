 const express=require('express') //returns a function
 const app=express(); //it returns an entire new object
  
// console.log(app); //this is an object with many properties and methods

app.listen(8080,()=>{console.log("connected succesfully");}); 