let PI=3.145;
let magi=68;
console.log("live class ka bhokaal");

function sqr(num){
    return num*num;
}

let obj={
    first:'kanishka',
    last:'saraswat',
    age:20,
    getName:function(){
        console.log(this.first+" "+this.last);
    }
}
console.log(PI);
console.log(sqr(5));
console.log(obj.first);
obj.getName();

// let a=16;
// for(let i=0;i<=a;i++){
//     if(i%5==0 && i%3==0){
//         console.log("fizzbuzz");
//     }
//     if(i%3==0){
//         console.log("fizz");
//     }
//     else if(i%5==0){
//         console.log("buzz");
//     }
//     // if(i%5==0 && i%3==0){
//     //     console.log("fizzbuzz");
//     // }
//     else{
//         console.log(i);
//     }
// }




let c3=1;
let c5=1;
for(let i=1;i<=20;i++){
    let str1="";
    if(c3===3){
        str1+="fizz";
        c3=0;
    };
    if(c5===5){
        str1+="buzz";
        c5=0;
    };
    if(str1===""){
        str1+=i;
    };
    c3++;
    c5++;

}


