// text1=process.argv;
// console.log(text1);
// let arr=process.argv.slice(2);
// console.log(arr);

// for( let i of arr){
//     console.log(i);
// }

const arr=parseInt(process.argv.pop()); //-->slice isslie ni kiuki we dont know kha p lie kr r hi h value
//-->parseint value string kointegeer m convert krdega kiuki jo array ati h after argv vo string hoti h

for(let i=0;i<=arr;i++){
    console.log(i);
}

 


